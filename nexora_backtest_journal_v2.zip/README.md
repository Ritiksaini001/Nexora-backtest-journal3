# Nexora Backtest & Journal v2

## Deploy from Android tablet
1. Download and extract this ZIP.
2. Create a GitHub repository called `nexora-backtest-journal`.
3. Upload `app.py` and `requirements.txt` (README optional).
4. Open https://share.streamlit.io/ and sign in with GitHub.
5. Create app, choose your repository, branch `main`, main file `app.py`, then deploy.
6. Open the deployed URL on your tablet.

## Focus
- OHLC CSV backtesting for EMA crossover with session filter, one trade/day, R metrics and downloadable results.
- Trade journal with emotion, rule adherence, setup grade and chart link.
- Journal analytics by strategy, market and trading psychology.

## CSV requirements
Columns: Open, High, Low, Close; include Date or Timestamp where possible. The current session filter assumes timestamps are UTC and converts to Asia/Kolkata.

## Limitations
No broker execution, automatic historical-data fetching, persistent database, or tick-level execution. Export journal CSV backups regularly. Test all outputs carefully.
